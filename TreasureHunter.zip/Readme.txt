This project was created in C language and its libraries
The game was designed and developed by -
Harsh Singh
Shamsheer Rahiman
Ishan Dandekar
Mohammed Amaan Ansari